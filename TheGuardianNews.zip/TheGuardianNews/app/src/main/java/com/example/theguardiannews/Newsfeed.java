package com.example.theguardiannews;

import java.util.List;

public class Newsfeed {
    private String mTitles;
    private String mCategoryName;
    private String mUrl;
    private List<String> mContributor;

    public Newsfeed(String titles, String categoryName,String url,List<String> contributor){
        mTitles = titles;
        mCategoryName = categoryName;
        mUrl = url;
        mContributor = contributor;
    }

    public String getTitles(){return mTitles;}
    public String getCategoryName(){return mCategoryName;}
    public String getUrl(){return mUrl;}
    public List<String> getContributor(){return mContributor;}
}
